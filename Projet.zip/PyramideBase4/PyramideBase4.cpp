#include <cstdio>
#include <cstdlib>
#include <GL/glut.h>
#include <jpeglib.h>
#include <jerror.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <cmath>

#ifndef PI
#define PI 3.14159265358979323846
#endif

// Rest of your code...

#ifdef __WIN32
#pragma comment(lib, "jpeg.lib")
#endif

const int largim = 512;
const int hautimg = 170;

unsigned char image[largim * hautimg * 3];
char presse;
int anglex = 30, angley = 20, xold, yold;

GLuint textureID;
glm::mat4 model, view, projection;

void affichage();
void clavier(unsigned char touche, int x, int y);
void souris(int boutton, int etat, int x, int y);
void sourismouv(int x, int y);
void redim(int l, int h);
void loadJpegImage(const char *fichier);
void setTexture();
void drawCone();

int main(int argc, char **argv)
{
    /* Chargement de la texture */
    loadJpegImage("./bat.jpg");

    /* Creation de la fenetre OpenGL */
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Texture Cone");

    /* Initialisation de l'etat d'OpenGL */
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glShadeModel(GL_FLAT);
    glEnable(GL_DEPTH_TEST);

    /* Mise en place de la projection perspective */
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, 1, 2.0, 5.0);
    glMatrixMode(GL_MODELVIEW);

    /* Parametrage du placage de textures */
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, largim, hautimg, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
    glEnable(GL_TEXTURE_2D);

    /* Mise en place des fonctions de rappel */
    glutDisplayFunc(affichage);
    glutKeyboardFunc(clavier);
    glutMouseFunc(souris);
    glutMotionFunc(sourismouv);
    glutReshapeFunc(redim);

    /* Entr�e dans la boucle principale glut */
    glutMainLoop();
    return 0;
}

void drawPyramid()
{
    const float baseSize = 1.5f;
    const float height = 2.0f;
    const int segments = 4; // Nombre de côtés du polygone de base (carré)

    glPushMatrix();
    glTranslatef(0.0f, -height / 2.0f, 0.0f);

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, textureID);

    // Dessine les côtés de la pyramide
    glBegin(GL_TRIANGLE_FAN);
    glTexCoord2f(0.5f, 0.5f);
    glVertex3f(0.0f, height / 2.0f, 0.0f);

    for (int i = 0; i <= segments; ++i)
    {
        float theta = (2.0f * PI * float(i)) / float(segments);
        float x = baseSize * cosf(theta);
        float y = baseSize * sinf(theta);

        float texCoordX = (cosf(theta) + 1.0f) * 0.5f;
        float texCoordY = (sinf(theta) + 1.0f) * 0.5f;

        glTexCoord2f(texCoordX, texCoordY);
        glColor3f(1.0, 1.0, 1.0);
        glVertex3f(x, -height / 2.0f, y);
    }
    glEnd();

    // Dessine la base de la pyramide sans texture
    glDisable(GL_TEXTURE_2D);
    glBegin(GL_POLYGON);
    for (int i = segments; i >= 0; --i)
    {
        float theta = (2.0f * PI * float(i)) / float(segments);
        float x = baseSize * cosf(theta);
        float y = baseSize * sinf(theta);

        glColor3f(1.0, 1.0, 1.0);
        glVertex3f(x, -height / 2.0f, y);
    }
    glEnd();

    glDisable(GL_TEXTURE_2D);
    glPopMatrix();
}

void affichage()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glLoadIdentity();

    gluLookAt(0.0, 0.0, 2.5, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
    glRotatef(angley, 1.0, 0.0, 0.0);
    glRotatef(anglex, 0.0, 1.0, 0.0);

    drawPyramid();

    glutSwapBuffers();
}

void clavier(unsigned char touche, int x, int y)
{
    switch (touche)
    {
    case 'l':
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glutPostRedisplay();
        break;
    case 'n':
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glutPostRedisplay();
        break;
    case 27: /* touche ESC */
        exit(0);
    default:
        break;
    }
}

void souris(int bouton, int etat, int x, int y)
{
    if (bouton == GLUT_LEFT_BUTTON && etat == GLUT_DOWN)
    {
        presse = 1;
        xold = x;
        yold = y;
    }
    if (bouton == GLUT_LEFT_BUTTON && etat == GLUT_UP)
        presse = 0;
}

void sourismouv(int x, int y)
{
    if (presse)
    {
        anglex = anglex + (x - xold);
        angley = angley + (y - yold);
        glutPostRedisplay();
    }

    xold = x;
    yold = y;
}

void redim(int l, int h)
{
    if (l < h)
        glViewport(0, (h - l) / 2, l, l);
    else
        glViewport((l - h) / 2, 0, h, h);
}

void loadJpegImage(const char *fichier)
{
    struct jpeg_decompress_struct cinfo;
    struct jpeg_error_mgr jerr;
    FILE *file;
    unsigned char *ligne;

    cinfo.err = jpeg_std_error(&jerr);
    jpeg_create_decompress(&cinfo);
#ifdef __WIN32
    if (fopen_s(&file, fichier, "rb") != 0)
    {
        fprintf(stderr, "Erreur : impossible d'ouvrir le fichier texture.jpg\n");
        exit(1);
    }
#elif __GNUC__
    if ((file = fopen(fichier, "rb")) == 0)
    {
        fprintf(stderr, "Erreur : impossible d'ouvrir le fichier texture.jpg\n");
        exit(1);
    }
#endif
    jpeg_stdio_src(&cinfo, file);
    jpeg_read_header(&cinfo, TRUE);

    if (cinfo.jpeg_color_space == JCS_GRAYSCALE)
    {
        fprintf(stdout, "Erreur : l'image doit etre de type RGB\n");
        exit(1);
    }

    jpeg_start_decompress(&cinfo);
    ligne = image;
    while (cinfo.output_scanline < cinfo.output_height)
    {
        ligne = image + 3 * largim * cinfo.output_scanline;
        jpeg_read_scanlines(&cinfo, &ligne, 1);
    }
    jpeg_finish_decompress(&cinfo);
    jpeg_destroy_decompress(&cinfo);
}
